<div <?php echo e($attributes->merge(['class' => 'panel'])); ?>>

    <?php if(isset($title)): ?>

        <div class="panel-header">

            <h2><?php echo e($title); ?></h2>

            <?php if(isset($actions)): ?>

                <div class="panel-actions">

                    <?php echo e($actions); ?>


                </div>

            <?php endif; ?>

        </div>

    <?php endif; ?>

    <div class="panel-body">

        <?php echo e($slot); ?>


    </div>

</div><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/panel.blade.php ENDPATH**/ ?>