<span <?php echo e($attributes->merge(['class' => 'badge'])); ?>>
    <?php echo e($slot); ?>

</span><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/badge.blade.php ENDPATH**/ ?>