<section class="page-header">

    <h1><?php echo e($title); ?></h1>

    <p><?php echo e($description); ?></p>

</section><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/page-header.blade.php ENDPATH**/ ?>