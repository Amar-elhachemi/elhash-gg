

<?php $__env->startSection('title', 'CS2 Pro Settings'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal522a3c8aadb4ccbcc229d59265244da1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1 = $attributes; } ?>
<?php $component = App\View\Components\PageHeader::resolve(['title' => '👑 Professional Player Settings','description' => 'Browse the settings used by the world\'s best Counter-Strike 2 players.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PageHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $attributes = $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $component = $__componentOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>

<div class="container pro-page">

    <div class="search-bar">

        <input
            id="playerSearch"
            type="text"
            placeholder="Search player, team or country...">

    </div>

    <div class="player-grid">

        <?php $__currentLoopData = [
            ['donk','🇷🇺','Team Spirit'],
            ['m0NESY','🇺🇦','Falcons'],
            ['ZywOo','🇫🇷','Vitality'],
            ['NiKo','🇧🇦','Falcons'],
            ['ropz','🇪🇪','Vitality'],
            ['s1mple','🇺🇦','FaZe'],
            ['frozen','🇸🇰','FaZe'],
            ['b1t','🇺🇦','NAVI'],
            ['jL','🇱🇹','NAVI'],
            ['broky','🇱🇻','FaZe'],
            ['torzsi','🇭🇺','MOUZ'],
            ['xertioN','🇮🇱','MOUZ']
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="pro-card">

            <div class="pro-header">

                <div class="flag"><?php echo e($player[1]); ?></div>

                <div>

                    <h3><?php echo e($player[0]); ?></h3>

                    <small><?php echo e($player[2]); ?></small>

                </div>

            </div>

            <div class="pro-body">

                <div><strong>DPI</strong><span>400</span></div>

                <div><strong>Sensitivity</strong><span>1.80</span></div>

                <div><strong>Resolution</strong><span>1280×960</span></div>

                <div><strong>Refresh</strong><span>360 Hz</span></div>

            </div>

            <a
                href="<?php echo e(route('cs2.crosshair')); ?>"
                class="btn btn-primary">

                View Crosshair →

            </a>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/pro-settings.blade.php ENDPATH**/ ?>