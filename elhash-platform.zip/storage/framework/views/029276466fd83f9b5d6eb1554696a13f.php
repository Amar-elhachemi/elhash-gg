

<?php $__env->startSection('title', 'Utilities'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">
    <div class="hero-content">
        <h1>Utilities</h1>

        <p>
            Gaming tools that save you time.
        </p>

        <a href="#" class="hero-button">
            Coming Soon
        </a>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/utilities.blade.php ENDPATH**/ ?>