

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">
    <div class="hero-content">

        <h1>
            The Ultimate Toolkit
            <br>
            For Competitive Gamers
        </h1>

        <p>
            Crosshairs. Lineups. Utilities. Statistics.
        </p>

        <a href="<?php echo e(route('cs2')); ?>" class="hero-button">
            Explore Tools
        </a>

    </div>
</section>

<section class="tools">

    <h2>Featured Tools</h2>

    <div class="tool-grid">

        <?php if (isset($component)) { $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07 = $attributes; } ?>
<?php $component = App\View\Components\FeatureCard::resolve(['title' => 'CS2 Tools','description' => 'Crosshair Generator, Pro Settings, Config Generator and more.','icon' => '🎯','route' => 'cs2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FeatureCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $attributes = $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $component = $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07 = $attributes; } ?>
<?php $component = App\View\Components\FeatureCard::resolve(['title' => 'Valorant Tools','description' => 'Crosshair Generator, Agent Guides and Lineups.','icon' => '🎮','route' => 'valorant'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FeatureCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $attributes = $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $component = $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07 = $attributes; } ?>
<?php $component = App\View\Components\FeatureCard::resolve(['title' => 'Gaming Utilities','description' => 'Sensitivity Converter, FPS Calculator and more.','icon' => '⚡','route' => 'utilities'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FeatureCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $attributes = $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $component = $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/home.blade.php ENDPATH**/ ?>