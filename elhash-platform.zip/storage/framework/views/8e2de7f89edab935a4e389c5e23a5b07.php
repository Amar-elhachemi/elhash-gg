<div class="background-grid"></div>

<div class="background-glow glow-1"></div>
<div class="background-glow glow-2"></div>

<div class="noise"></div><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/background.blade.php ENDPATH**/ ?>