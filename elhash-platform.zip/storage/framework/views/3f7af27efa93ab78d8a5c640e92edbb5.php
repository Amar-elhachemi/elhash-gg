<section <?php echo e($attributes->merge(['class' => 'section'])); ?>>
    <?php echo e($slot); ?>

</section><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/section.blade.php ENDPATH**/ ?>