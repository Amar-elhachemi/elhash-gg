

<?php $__env->startSection('title', 'CS2'); ?>

<?php $__env->startSection('content'); ?>

<section class="page-header">

    <h1>🎯 Counter-Strike 2</h1>

    <p>
        Everything you need to improve your game.
    </p>

</section>

<section class="dashboard">

    <a href="#" class="dashboard-card">

        <div class="emoji">🎯</div>

        <h2>Crosshair Generator</h2>

        <p>Create professional CS2 crosshairs.</p>

    </a>

    <a href="#" class="dashboard-card">

        <div class="emoji">⚙</div>

        <h2>Config Generator</h2>

        <p>Generate your own practice config.</p>

    </a>

    <a href="#" class="dashboard-card">

        <div class="emoji">📊</div>

        <h2>Pro Player Settings</h2>

        <p>Browse settings from professional players.</p>

    </a>

    <a href="#" class="dashboard-card">

        <div class="emoji">🗺</div>

        <h2>Interactive Maps</h2>

        <p>Smoke lineups and callouts.</p>

    </a>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2.blade.php ENDPATH**/ ?>