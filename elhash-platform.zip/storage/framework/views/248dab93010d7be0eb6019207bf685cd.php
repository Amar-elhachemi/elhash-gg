

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">
    <div class="hero-content">
        <h1>About elhash.gg</h1>

        <p>
            The ultimate gaming toolkit built with Laravel.
        </p>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/about.blade.php ENDPATH**/ ?>