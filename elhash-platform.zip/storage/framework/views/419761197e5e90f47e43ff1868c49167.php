<div class="crosshair-page">

    <div class="crosshair-top">

        <?php echo $__env->make('cs2.crosshair.partials.players', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('cs2.crosshair.partials.preview', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>

    <?php echo $__env->make('cs2.crosshair.partials.controls', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('cs2.crosshair.partials.output', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('cs2.crosshair.partials.toolbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/crosshair/index.blade.php ENDPATH**/ ?>