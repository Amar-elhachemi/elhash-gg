<?php if (isset($component)) { $__componentOriginal36665f0dc0e45320e21db1e20a989acf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36665f0dc0e45320e21db1e20a989acf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel','data' => ['title' => '👑 Professional Players']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => '👑 Professional Players']); ?>


    <div class="players-header">

        <h2>👑 Professional Players</h2>

        <input
            type="text"
            id="playerSearch"
            placeholder="Search player...">

    </div>

    <div class="players-grid">

        <button class="player-card" data-player="donk">
            <strong>🇷🇺 donk</strong>
            <small>Team Spirit</small>
        </button>

        <button class="player-card" data-player="m0NESY">
            <strong>🇺🇦 m0NESY</strong>
            <small>Falcons</small>
        </button>

        <button class="player-card" data-player="ZywOo">
            <strong>🇫🇷 ZywOo</strong>
            <small>Vitality</small>
        </button>

        <button class="player-card" data-player="NiKo">
            <strong>🇧🇦 NiKo</strong>
            <small>Falcons</small>
        </button>

        <button class="player-card" data-player="ropz">
            <strong>🇪🇪 ropz</strong>
            <small>Vitality</small>
        </button>

        <button class="player-card" data-player="s1mple">
            <strong>🇺🇦 s1mple</strong>
            <small>FaZe</small>
        </button>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $attributes = $__attributesOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $component = $__componentOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__componentOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/components/players.blade.php ENDPATH**/ ?>