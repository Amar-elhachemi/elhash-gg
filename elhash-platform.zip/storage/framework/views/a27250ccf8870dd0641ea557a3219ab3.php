<div <?php echo e($attributes->merge(['class' => 'container'])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/container.blade.php ENDPATH**/ ?>