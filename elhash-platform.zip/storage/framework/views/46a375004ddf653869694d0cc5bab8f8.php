<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'elhash.gg'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')([
    'resources/css/app.css',
    'resources/js/app.js'
]); ?>

<?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<nav class="navbar">

    <a href="<?php echo e(route('home')); ?>" class="logo">
    elhash<span>.gg</span>
</a>

<div class="nav-links">
    <a href="<?php echo e(route('home')); ?>"
       class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
        Home
    </a>

    <a href="<?php echo e(route('cs2')); ?>"
       class="<?php echo e(request()->routeIs('cs2*') ? 'active' : ''); ?>">
        CS2
    </a>

    <a href="<?php echo e(route('valorant')); ?>"
       class="<?php echo e(request()->routeIs('valorant*') ? 'active' : ''); ?>">
        Valorant
    </a>

    <a href="<?php echo e(route('utilities')); ?>"
       class="<?php echo e(request()->routeIs('utilities*') ? 'active' : ''); ?>">
        Utilities
    </a>

    <a href="<?php echo e(route('about')); ?>"
       class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">
        About
    </a>
</div>

</nav>

<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/layouts/app.blade.php ENDPATH**/ ?>