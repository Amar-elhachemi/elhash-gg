<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'ELHASH.GG'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.background','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('background'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7)): ?>
<?php $attributes = $__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7; ?>
<?php unset($__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7)): ?>
<?php $component = $__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7; ?>
<?php unset($__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7); ?>
<?php endif; ?>
    
    <div class="particles"></div>

<header class="navbar">

    <div class="container navbar-container">

        <a href="<?php echo e(route('home')); ?>" class="logo">

            <span class="logo-icon">⬢</span>

            <span class="logo-text">
                ELHASH<span>.GG</span>
            </span>

        </a>

        <nav class="nav-links">

    <a href="<?php echo e(route('home')); ?>"
       class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
        Home
    </a>

    <a href="<?php echo e(route('cs2')); ?>"
       class="<?php echo e(request()->routeIs('cs2*') ? 'active' : ''); ?>">
        CS2
    </a>

    <a href="<?php echo e(route('valorant')); ?>"
       class="<?php echo e(request()->routeIs('valorant*') ? 'active' : ''); ?>">
        Valorant
    </a>

    <a href="<?php echo e(route('utilities')); ?>"
       class="<?php echo e(request()->routeIs('utilities*') ? 'active' : ''); ?>">
        Utilities
    </a>

    <a href="<?php echo e(route('about')); ?>"
       class="<?php echo e(request()->routeIs('about*') ? 'active' : ''); ?>">
        About
    </a>

</nav>

<div class="mobile-menu">

    <a href="<?php echo e(route('home')); ?>">Home</a>
    <a href="<?php echo e(route('cs2')); ?>">CS2</a>
    <a href="<?php echo e(route('valorant')); ?>">Valorant</a>
    <a href="<?php echo e(route('utilities')); ?>">Utilities</a>
    <a href="<?php echo e(route('about')); ?>">About</a>

    <a
        href="<?php echo e(route('cs2.crosshair')); ?>"
        class="btn btn-primary">

        Explore Tools →

    </a>

</div>

        <div class="nav-actions">

            <a
                href="<?php echo e(route('cs2.crosshair')); ?>"
                class="btn btn-primary">

                Explore Tools →

            </a>

        </div>

        <button class="mobile-toggle">

            ☰

        </button>

    </div>

</header>

<main>

    <?php echo $__env->yieldContent('content'); ?>

</main>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php if (isset($component)) { $__componentOriginal7cfab914afdd05940201ca0b2cbc009b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7cfab914afdd05940201ca0b2cbc009b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7cfab914afdd05940201ca0b2cbc009b)): ?>
<?php $attributes = $__attributesOriginal7cfab914afdd05940201ca0b2cbc009b; ?>
<?php unset($__attributesOriginal7cfab914afdd05940201ca0b2cbc009b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7cfab914afdd05940201ca0b2cbc009b)): ?>
<?php $component = $__componentOriginal7cfab914afdd05940201ca0b2cbc009b; ?>
<?php unset($__componentOriginal7cfab914afdd05940201ca0b2cbc009b); ?>
<?php endif; ?>
</body>

</html><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/layouts/app.blade.php ENDPATH**/ ?>