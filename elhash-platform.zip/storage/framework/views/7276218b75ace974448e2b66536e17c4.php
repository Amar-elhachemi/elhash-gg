

<?php $__env->startSection('title', 'CS2 Crosshair Generator'); ?>

<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/cs2/crosshair.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal522a3c8aadb4ccbcc229d59265244da1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1 = $attributes; } ?>
<?php $component = App\View\Components\PageHeader::resolve(['title' => '🎯 CS2 Crosshair Generator','description' => 'Create, preview and export professional Counter-Strike 2 crosshairs.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PageHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $attributes = $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $component = $__componentOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>

<div class="crosshair-container">

    <!-- ========================= -->
    <!-- PREVIEW -->
    <!-- ========================= -->

    <div class="preview-panel">

        <div class="preview-header">

            <h2>Live Preview</h2>

            <div class="preview-actions">

    <button class="map-btn active" data-map="mirage">Mirage</button>

    <button class="map-btn" data-map="dust2">Dust II</button>

    <button class="map-btn" data-map="inferno">Inferno</button>

    <button class="map-btn" data-map="nuke">Nuke</button>

    <button class="map-btn" data-map="ancient">Ancient</button>

    <button class="map-btn" data-map="anubis">Anubis</button>

</div>

        </div>

        <div class="preview-screen">

            <div id="crosshair-preview">

                <div class="arm top"></div>
                <div class="arm bottom"></div>
                <div class="arm left"></div>
                <div class="arm right"></div>

                <div id="center-dot"></div>

            </div>

        </div>

    </div>

    <!-- ========================= -->
    <!-- CONTROLS -->
    <!-- ========================= -->

    <div class="controls-panel">

        <div class="panel-section">

            <h2>⚙ Crosshair Settings</h2>

            <div class="control-group">

                <label>

                    Size

                    <span id="sizeValue">2</span>

                </label>

                <input
                    type="range"
                    id="size"
                    min="1"
                    max="10"
                    value="2">

            </div>

            <div class="control-group">

                <label>

                    Thickness

                    <span id="thicknessValue">1</span>

                </label>

                <input
                    type="range"
                    id="thickness"
                    min="0.5"
                    max="5"
                    step="0.5"
                    value="1">

            </div>

            <div class="control-group">

                <label>

                    Gap

                    <span id="gapValue">-3</span>

                </label>

                <input
                    type="range"
                    id="gap"
                    min="-5"
                    max="10"
                    value="-3">

            </div>

            <div class="control-group">

                <label>Color</label>

                <input
                    type="color"
                    id="color"
                    value="#00ff00">

            </div>

            <div class="quick-colors">

                <button class="color green" data-color="#00ff00"></button>
                <button class="color red" data-color="#ff3b30"></button>
                <button class="color blue" data-color="#3b82f6"></button>
                <button class="color yellow" data-color="#facc15"></button>
                <button class="color white" data-color="#ffffff"></button>
                <button class="color purple" data-color="#a855f7"></button>

            </div>

            <div class="checkbox-group">

                <label>

                    <input
                        type="checkbox"
                        id="centerDot">

                    Center Dot

                </label>

                <label>

                    <input
                        type="checkbox"
                        id="outline">

                    Outline

                </label>

            </div>

        </div>

        <hr>

        <div class="panel-section">

            <div class="players-header">

                <h2>👑 Professional Players</h2>

                <input
                    type="text"
                    id="playerSearch"
                    placeholder="Search player...">

            </div>

            <div class="players-grid">

                <button class="player-card" data-player="donk">
                    <strong>🇷🇺 donk</strong>
                    <small>Team Spirit</small>
                </button>

                <button class="player-card" data-player="m0NESY">
                    <strong>🇺🇦 m0NESY</strong>
                    <small>Falcons</small>
                </button>

                <button class="player-card" data-player="ZywOo">
                    <strong>🇫🇷 ZywOo</strong>
                    <small>Vitality</small>
                </button>

                <button class="player-card" data-player="NiKo">
                    <strong>🇧🇦 NiKo</strong>
                    <small>Falcons</small>
                </button>

                <button class="player-card" data-player="ropz">
                    <strong>🇪🇪 ropz</strong>
                    <small>Vitality</small>
                </button>

                <button class="player-card" data-player="s1mple">
                    <strong>🇺🇦 s1mple</strong>
                    <small>FaZe</small>
                </button>

            </div>

        </div>

        <hr>

        <div class="panel-section">

            <h2>📋 Actions</h2>

            <div class="action-buttons">

                <button
                    id="copyConfig"
                    class="primary-btn">

                    📋 Copy Crosshair

                </button>

                <button
                    id="resetCrosshair"
                    class="secondary-btn">

                    🔄 Reset

                </button>

                <button
                    id="exportCFG"
                    class="secondary-btn">

                    📥 Export CFG

                </button>

            </div>

        </div>

        <hr>

        <div class="panel-section">

            <h2>📄 Generated Config</h2>

            <textarea
                id="configOutput"
                rows="10"
                readonly></textarea>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/cs2/crosshair.js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/crosshair-generator.blade.php ENDPATH**/ ?>