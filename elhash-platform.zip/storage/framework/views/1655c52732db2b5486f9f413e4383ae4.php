<a href="<?php echo e(route($route)); ?>" class="tool-card">

    <div class="icon"><?php echo e($icon); ?></div>

    <h3><?php echo e($title); ?></h3>

    <p><?php echo e($description); ?></p>

</a><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/feature-card.blade.php ENDPATH**/ ?>