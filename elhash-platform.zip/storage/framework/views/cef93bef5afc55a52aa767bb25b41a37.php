<div <?php echo e($attributes->merge(['class' => 'card'])); ?>>

    <div class="card-glow"></div>

    <div class="card-content">

        <?php echo e($slot); ?>


    </div>

</div><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/card.blade.php ENDPATH**/ ?>