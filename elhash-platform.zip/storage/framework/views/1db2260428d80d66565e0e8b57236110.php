<div class="players-panel card">

    <div class="card-content">

        <div class="players-header">

            <h3>Professional Players</h3>

            <p>Load crosshairs from the world's best players.</p>

        </div>

        <div class="player-search">

            <input
                id="playerSearch"
                type="text"
                placeholder="Search player...">

        </div>

        <div class="players-list">

            <button class="player-card active" data-player="donk">

                <span class="flag">🇷🇺</span>

                <div>

                    <strong>donk</strong>

                    <small>Team Spirit</small>

                </div>

            </button>

            <button class="player-card" data-player="m0NESY">

                <span class="flag">🇺🇦</span>

                <div>

                    <strong>m0NESY</strong>

                    <small>Falcons</small>

                </div>

            </button>

            <button class="player-card" data-player="ZywOo">

                <span class="flag">🇫🇷</span>

                <div>

                    <strong>ZywOo</strong>

                    <small>Vitality</small>

                </div>

            </button>

            <button class="player-card" data-player="NiKo">

                <span class="flag">🇧🇦</span>

                <div>

                    <strong>NiKo</strong>

                    <small>Falcons</small>

                </div>

            </button>

            <button class="player-card" data-player="ropz">

                <span class="flag">🇪🇪</span>

                <div>

                    <strong>ropz</strong>

                    <small>Vitality</small>

                </div>

            </button>

            <button class="player-card" data-player="s1mple">

                <span class="flag">🇺🇦</span>

                <div>

                    <strong>s1mple</strong>

                    <small>FaZe</small>

                </div>

            </button>

        </div>

    </div>

</div><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/crosshair/partials/players.blade.php ENDPATH**/ ?>