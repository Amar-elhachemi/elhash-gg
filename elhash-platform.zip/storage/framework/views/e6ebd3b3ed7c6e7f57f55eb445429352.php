<a href="<?php echo e(route($route)); ?>" class="dashboard-card">

    <div class="emoji"><?php echo e($icon); ?></div>

    <h2><?php echo e($title); ?></h2>

    <p><?php echo e($description); ?></p>

</a><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/tool-card.blade.php ENDPATH**/ ?>