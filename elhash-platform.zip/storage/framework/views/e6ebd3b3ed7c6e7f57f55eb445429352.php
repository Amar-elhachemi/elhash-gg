<a href="<?php echo e(route($route)); ?>" class="tool-card">

    <div class="tool-card-top">

        <div class="tool-icon">

            <?php echo e($icon); ?>


        </div>

        <span class="tool-status">

            Available

        </span>

    </div>

    <div class="tool-content">

        <h2>

            <?php echo e($title); ?>


        </h2>

        <p>

            <?php echo e($description); ?>


        </p>

    </div>

    <div class="tool-footer">

        <span>

            Launch Tool

        </span>

        <span class="arrow">

            →

        </span>

    </div>

</a><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/components/tool-card.blade.php ENDPATH**/ ?>