

<?php $__env->startSection('title', 'CS2'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal522a3c8aadb4ccbcc229d59265244da1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1 = $attributes; } ?>
<?php $component = App\View\Components\PageHeader::resolve(['title' => '🎯 Counter-Strike 2','description' => 'Everything you need to improve your game.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PageHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $attributes = $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $component = $__componentOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>

<section class="dashboard">

    <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Crosshair Generator','description' => 'Create professional CS2 crosshairs.','icon' => '🎯','route' => 'cs2.crosshair'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Config Generator','description' => 'Generate practice configs.','icon' => '⚙','route' => 'cs2.config'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Pro Settings','description' => 'Browse professional player settings.','icon' => '👑','route' => 'cs2.prosettings'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Maps','description' => 'Interactive maps and callouts.','icon' => '🗺','route' => 'cs2.maps'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/index.blade.php ENDPATH**/ ?>