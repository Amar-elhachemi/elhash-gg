```blade


<?php $__env->startSection('title', 'Counter-Strike 2'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal522a3c8aadb4ccbcc229d59265244da1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1 = $attributes; } ?>
<?php $component = App\View\Components\PageHeader::resolve(['title' => '🎮 Counter-Strike 2','description' => 'Professional tools, generators and resources built for every CS2 player.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PageHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $attributes = $__attributesOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__attributesOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1)): ?>
<?php $component = $__componentOriginal522a3c8aadb4ccbcc229d59265244da1; ?>
<?php unset($__componentOriginal522a3c8aadb4ccbcc229d59265244da1); ?>
<?php endif; ?>

<section class="dashboard-page">

    <div class="container">

        <div class="dashboard-grid">

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Crosshair Generator','description' => 'Create, preview, import and export professional crosshairs.','icon' => '🎯','route' => 'cs2.crosshair'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Config Generator','description' => 'Generate complete CS2 autoexec and practice configs.','icon' => '⚙️','route' => 'cs2.config'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Professional Settings','description' => 'Browse settings used by the world\'s best players.','icon' => '👑','route' => 'cs2.prosettings'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Maps','description' => 'Interactive competitive maps with callouts and utilities.','icon' => '🗺️','route' => 'cs2.maps'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

        </div>

        <div class="dashboard-section">

            <?php if (isset($component)) { $__componentOriginal36665f0dc0e45320e21db1e20a989acf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36665f0dc0e45320e21db1e20a989acf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <h2 class="panel-title">
                    🚀 What's inside ELHASH.GG
                </h2>

                <div class="feature-grid">

                    <div class="feature-item">
                        <span>🎯</span>
                        <div>
                            <h3>Crosshair Builder</h3>
                            <p>Create and export tournament-ready crosshairs.</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <span>⚙️</span>
                        <div>
                            <h3>CFG Builder</h3>
                            <p>Create complete autoexec and practice configurations.</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <span>👑</span>
                        <div>
                            <h3>Pro Database</h3>
                            <p>Crosshairs, configs, resolutions and peripherals.</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <span>🗺️</span>
                        <div>
                            <h3>Interactive Maps</h3>
                            <p>Callouts, smokes, flashes and executes.</p>
                        </div>
                    </div>

                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $attributes = $__attributesOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $component = $__componentOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__componentOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>

        </div>

        <div class="dashboard-section">

            <?php if (isset($component)) { $__componentOriginal36665f0dc0e45320e21db1e20a989acf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36665f0dc0e45320e21db1e20a989acf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <h2 class="panel-title">
                    🛣 Development Roadmap
                </h2>

                <div class="roadmap">

                    <div class="roadmap-item completed">
                        <span>✅</span>
                        <div>
                            <h3>Crosshair Generator</h3>
                            <p>Completed and fully functional.</p>
                        </div>
                    </div>

                    <div class="roadmap-item">
                        <span>🟠</span>
                        <div>
                            <h3>Config Generator</h3>
                            <p>Coming in the next development sprint.</p>
                        </div>
                    </div>

                    <div class="roadmap-item">
                        <span>🟠</span>
                        <div>
                            <h3>Professional Settings</h3>
                            <p>Player database with filters and search.</p>
                        </div>
                    </div>

                    <div class="roadmap-item">
                        <span>🟠</span>
                        <div>
                            <h3>Interactive Maps</h3>
                            <p>Smokes, flashes, executes and callouts.</p>
                        </div>
                    </div>

                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $attributes = $__attributesOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $component = $__componentOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__componentOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
```

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/index.blade.php ENDPATH**/ ?>