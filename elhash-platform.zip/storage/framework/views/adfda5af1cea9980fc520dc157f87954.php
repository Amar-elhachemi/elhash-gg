

<?php $__env->startSection('title','Counter-Strike 2'); ?>

<?php $__env->startSection('content'); ?>

<section class="dashboard-page">

    <div class="container">

        <div class="dashboard-header">

            <h1>
                Counter-Strike 2
            </h1>

            <p>
                Everything you need to improve your gameplay.
                Crosshairs, configs, maps and professional settings,
                all in one place.
            </p>

        </div>

        <div class="dashboard-grid">

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Crosshair Generator','description' => 'Create professional CS2 crosshairs.','icon' => '🎯','route' => 'cs2.crosshair'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Config Generator','description' => 'Generate practice configs.','icon' => '⚙','route' => 'cs2.config'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Pro Settings','description' => 'Browse professional player settings.','icon' => '👑','route' => 'cs2.prosettings'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0 = $attributes; } ?>
<?php $component = App\View\Components\ToolCard::resolve(['title' => 'Maps','description' => 'Interactive maps and callouts.','icon' => '🗺','route' => 'cs2.maps'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tool-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ToolCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $attributes = $__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__attributesOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0)): ?>
<?php $component = $__componentOriginal65f7d0e669685bd9988bc1509ee7bde0; ?>
<?php unset($__componentOriginal65f7d0e669685bd9988bc1509ee7bde0); ?>
<?php endif; ?>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\amare\Desktop\GITHUB\elhash-platform\resources\views/cs2/index.blade.php ENDPATH**/ ?>