<section class="page-header">

    <h1>{{ $title }}</h1>

    <p>{{ $description }}</p>

</section>