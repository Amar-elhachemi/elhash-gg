import { elements } from "./config";
import { updateCrosshair } from "./preview";

console.log("1");

updateCrosshair();

console.log("2");